from django.shortcuts import render
from rest_framework import generics
from basics.models import Student
from basics.serializers import StudentSerializer
from rest_framework.exceptions import ValidationError

# Create your views here.


class StudentList(generics.ListCreateAPIView):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
class StudentDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset=Student
    serializer_class=StudentSerializer



class GetItemFromStudentView(generics.ListAPIView):
    serializer_class = StudentSerializer
    
    def get_queryset(self):
        #name=self.kwargs['name']
        data=self.request.data
        #name=data.get("name")
        #id=data.get("id")
        #roll=data.get("roll")
        city=data.get("city")
        #print(city)
        queryset=Student.objects.filter(city__icontains=city).order_by('roll').reverse()
        #queryset = Student.objects.filter(name__iexact=name).filter(id=id)   #use for and operation
        #queryset = Student.objects.filter(name__iexact=name) | Student.objects.filter(id=id)   #use for or operation
        #queryset = Student.objects.filter(roll__gte=roll)   #use for greater than equal
        #queryset = Student.objects.order_by('roll')  #use for orderby roll no
        #queryset = Student.objects.order_by('name')   #use for greater than equal



        if queryset:

            
            return queryset
        else:
             #raise ValidationError({"error": ["You don't have enough permission."]})
             raise ValidationError("Not data matching")



        #return queryset    